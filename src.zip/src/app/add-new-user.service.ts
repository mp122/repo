import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { baseUrl } from 'src/environments/environment';
import { map, catchError } from 'rxjs/operators';


@Injectable({
  providedIn: 'root'
})
export class AddNewUserService {

  constructor(private http:HttpClient) { }

  newUser(data: any):Observable<any>{
    console.log("Loi==>", data);
    const token = sessionStorage.getItem("token");
    const requestOptions: Object  = { 
      name : data.name,
      email: data.email, 
      password: data.password 
  }

  console.log("var===>>", requestOptions);
    return this.http.post(`${baseUrl}users/newUser`,data).pipe(
      map((newUseradded: any) =>{
        return newUseradded;
      })
    );
  }
}
