import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { Router } from '@angular/router';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { AddNewUserService } from '../add-new-user.service';


@Component({
  selector: 'app-new-user',
  templateUrl: './new-user.component.html',
  styleUrls: ['./new-user.component.css',
              '../../../src/main_style.css'
          ]
})
export class NewUserComponent implements OnInit {

  formGroup!: FormGroup;
  token: any;

  constructor(
    private newuseraddservice: AddNewUserService,
    private router: Router
    ) { }

  ngOnInit(): void {
    this.initForm();
    
  }

    initForm(){
      this.formGroup = new FormGroup({
        name: new FormControl('',[Validators.required]),
        email: new FormControl('',[Validators.required]),
        password: new FormControl('',[Validators.required])
      })
    }
  
    addNewuser(){
      if(this.formGroup.valid){
        console.log(this.formGroup.value);  
        this.newuseraddservice.newUser(this.formGroup.value).subscribe(result =>{
          if(result.success){
            alert(result.message);
            console.log(result.message);
          }
          else{
            console.log(result.message);
            alert(result.message);
            this.router.navigate(['/']);
          }
        });
      }
    }
  }
