import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { baseUrl } from 'src/environments/environment';
import { map, catchError } from 'rxjs/operators';
import { BehaviorSubject } from 'rxjs';


@Injectable({
  providedIn: 'root'
})
export class AuthServiceService {

  private userEmail = new BehaviorSubject("Default");


  constructor(private http:HttpClient) { }

  login(data: any):Observable<any>{
    
    console.log("Login Data ==>", data);
    
    return this.http.post(`${baseUrl}users/login`,data).pipe(
      map((user: any) =>{
        sessionStorage.setItem("token", user.token);
        //sessionStorage.setItem("Email", data.email);    
        //sessionStorage.setItem("token", user.token);
        return user;
      })
    );
  }



  getToken() {
    return sessionStorage.getItem("token");
  }

}
