import { TestBed } from '@angular/core/testing';

import { NewuseraddService } from './newuseradd.service';

describe('NewuseraddService', () => {
  let service: NewuseraddService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(NewuseraddService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
